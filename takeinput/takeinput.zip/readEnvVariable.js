const Result = process.env.USERNAME;
console.log('Hello'+ " "+Result)